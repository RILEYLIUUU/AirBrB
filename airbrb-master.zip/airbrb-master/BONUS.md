Bonus：

1.Password can be hidden when logging in
2.If you are not logged in, you cannot see the booking button and review button.
3.When on the booking list, users are only allowed to book within the range of the host’s publish
4.You can choose whether to remain anonymous when commenting. And when viewing the corresponding review, the username will become anonymous.

Other hits:  
The loading speed will be slower when opening a webpage at the first time.

Occasionally there will be some unknown errors, but they will not affect the front-end operation. Please continue scoring after turning off the error prompts.

When you open a web page under normal circumstances, there are "sign in" and "register" buttons in the upper right corner of the screen.
After logging in, these two buttons become "logout" and "your listing"
If you encounter "logout" and "your listing" in the upper right corner without logging in, please try clearing the browser cache and trying again. Or enter the Login page directly through the url.
This is the answer I got on ed: https://edstem.org/au/courses/13869/discussion/1709491

After the user makes a booking, please switch to the host account, enter from the "your listings" button, click "view booking history" corresponding to the list, and choose to accept or reject the order.

For 2.6.3, the json file in airbrb/frontend/src/static/2.6.json
